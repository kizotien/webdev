import React, { useState } from 'react';
import './App.css';
import Select from 'react-select';

import {
  InputGroup,
  Input,
  InputGroupAddon,
  Button,
  FormGroup,
  Label,
  Spinner
} 
from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import axios from 'axios';
import BookCard from './BookCard.jsx';
import Form from 'reactstrap/lib/Form';


function App() {
  // States
  const [maxResults, setMaxResults] = useState(10);
  const [startIndex, setStartIndex] = useState(1);

  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [cards, setCards] = useState([]);

  // Handle Search
  const handleSubmit = () => {    
    
      global.config.i18n.welcome.en5 = 2

    setLoading(true);
    if (maxResults > 40 || maxResults < 1) {
      toast.error('max results must be between 1 and 40');
    } else {
      axios
        .get(
          `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${maxResults}&startIndex=${startIndex}`
        )
        .then(res => {
          if (startIndex >= res.data.totalItems || startIndex < 1) {
            toast.error(
              `max reults must be between 1 and ${res.data.totalItems}`
            );
          } else {
            if (res.data.items.length > 0) {
              setCards(res.data.items);
              setLoading(false);
            }
          }
        })
        .catch(err => {
          setLoading(true);
          console.log(err.response);          
        });
    }
   // }
  };


// for select (REACT)
  const handleSort = () =>  {
    global.config.i18n.welcome.en4[0] = 111
    global.config.i18n.welcome.en7 = 222
    const sb = document.querySelector('#framework')
    global.config.i18n.welcome.string1 = sb.value
    console.log('THIS VALUE', global.config.i18n.welcome.string1) 
    global.config.i18n.welcome.en5 = 1
    axios
        .get(
          `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${maxResults}&startIndex=${startIndex}`
        )
        .then(res => {
           
            if (res.data.items.length > 0) {
              setCards(res.data.items);
              setLoading(false);
            }   
        })
        .catch(err => {
          setLoading(true);
          console.log(err.response);          
        });
    
      onclick = (event) => {
        event.preventDefault();
        
        //alert(sb.value);
        console.log(sb.value);
      }
      
  };

  
  // Main Show Case
  const mainHeader = () => {
    
    return (
      <div className='main-image d-flex justify-content-center align-items-center flex-column'>
        {/* Overlay */}
        <div className='filter'></div>
        <h1
          className='display-2 text-center text-white mb-3'
          style={{ zIndex: 2 }}
        >
          Google Books
        </h1>
        <div style={{ width: '60%', zIndex: 2 }}>
          <InputGroup size='lg' className='mb-3'>
            <Input
              placeholder='Book Search'
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
            <InputGroupAddon addonType='append'>
              <Button color='secondary' onClick={handleSubmit}>
                <i className='fas fa-search'></i>
              </Button>
            </InputGroupAddon>
          </InputGroup>
          <div className='d-flex text-white justify-content-center'>
            <FormGroup>
            <Label for="framework">Sort Order:</Label>
            <select onChange={handleSort} id="framework">          
                <option value="0">Order Added</option>
                <option value="1">Title Ascending</option>
                <option value="2">Title Descending</option>
            </select>     
            </FormGroup>
          </div>
          
          <div className='d-flex text-white justify-content-center'>
            <FormGroup >
              <Label for='maxResults'>Max Results</Label>
              <Input
                type='number'
                id='maxResults'
                placeholder='Max Results'
                value={maxResults}
                onChange={e => setMaxResults(e.target.value)}
              />
            </FormGroup>
            
            <FormGroup className='ml-5'>
              <Label for='startIndex'>Start Index</Label>
              <Input
                type='number'
                id='startIndex'
                placeholder='Start Index'
                value={startIndex}
                onChange={e => setStartIndex(e.target.value)}
              />
            </FormGroup>
          </div>
        </div>
      </div>
    );
  };


// for outputing, and calculating arrays
  const handleCards = () => {
    if (loading) {
      return (
        <div className='d-flex justify-content-center mt-3'>
          <Spinner style={{ width: '3rem', height: '3rem' }} />
        </div>
      );
    } else {
    
        if (global.config.i18n.welcome.en4[0] == 111 &&  global.config.i18n.welcome.en7 == 111) {
          
        //if increment = 1
        //loop normally without cards below to get NATURAL ORDER

        //or just search

        
    

        console.log("YES")  

        var cards2 = {};
        for (var i in cards)
        cards2[i] = cards[i];
        for(let i=0; i < maxResults; i++) {
          cards[i] = cards2[global.config.i18n.welcome.en2[i]]
          console.log("cards ", global.config.i18n.welcome.en2[i])
        }
       

        const items = cards.map((item, i) => {
          console.log(i)
          let thumbnail = '';
          let connect = ' ' + [i];
          
          if (item.volumeInfo.imageLinks) {
            thumbnail = item.volumeInfo.imageLinks.thumbnail;
          }
  
          let test = [];
         
          return (
            <div className='col-lg-4 mb-3' key={item.id}>              
              <BookCard
                thumbnail={thumbnail}
                pageCount={item.volumeInfo.pageCount}
                title={item.volumeInfo.title}
                language={item.volumeInfo.language}
                authors={item.volumeInfo.authors}
                publisher={item.volumeInfo.publisher}
                description={item.volumeInfo.description}
                previewLink={item.volumeInfo.previewLink}
                infoLink={item.volumeInfo.infoLink}
                connect= {connect}
                number= {i}
                test = {item.volumeInfo.title}
              />             
            </div>            
          );    
                
        } 
        );
        return (
          <div className='container my-5'>
            <div className='row'> {items}</div>
          </div>
        );
      } else {

      global.config.i18n.welcome.en7 = 111
      const items = cards.map((item, i) => {
      console.log(i)
      let thumbnail = '';
      let connect = ' ' + [i];  
    
      if (item.volumeInfo.imageLinks) {
        thumbnail = item.volumeInfo.imageLinks.thumbnail;
      }

      return (
        <div className='col-lg-4 mb-3' key={item.id}>
          <BookCard            
            thumbnail={thumbnail}
            pageCount={item.volumeInfo.pageCount}
            title={item.volumeInfo.title}
            language={item.volumeInfo.language}
            authors={item.volumeInfo.authors}
            publisher={item.volumeInfo.publisher}
            description={item.volumeInfo.description}
            previewLink={item.volumeInfo.previewLink}
            infoLink={item.volumeInfo.infoLink}
            connect= {connect}
            number= {i}
          />
        </div>
      );

      } 
      );
      return (
        <div className='container my-5'>
          <div className='row'>{items}</div>
        </div>
      );
    }
  }
  };
  return (
    <div className='w-100 h-100'>
      {mainHeader()}
      {handleCards()}
   
      <ToastContainer />
    </div>
  );
}

export default App;
