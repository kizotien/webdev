import React, { Component } from 'react';
import className from 'classnames';
import Select from 'react-select';
import movies from './movies.json';
import styles from './options.css';

const Option = props => {
  const { innerProps, innerRef, data } = props;
  const cx = className.bind(styles);
  const classes = cx({
    'custom-option': true
  });
  return (
    <article ref={innerRef} {...innerProps} className={classes}>
      <h4>{data.title}</h4>
      <h5>Genre: {data.genre}</h5>
      <h6>
        {data.last_name}, {data.first_name}
      </h6>
    </article>
  );
};

export default class MySelect extends Component {
  customFilter = (option, inputValue) => {
    const reg = new RegExp(`^${inputValue}`);
    return reg.test(option.label);
  };

  getOptionLabel = option => `${option.genre}: ${option.title}`;

  getOptionValue = option => option.id;

  render() {
    return (
      <Select
        name="movie"
        id="movie"
        options={movies}
        components={{ Option }}
        filterOption={this.customFilter}
        getOptionValue={this.getOptionValue}
        getOptionLabel={this.getOptionLabel}
      />
    );
  }
}
