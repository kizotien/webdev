import React, { useState } from 'react';
import { Card, CardTitle, CardImg, CardBody, Button, Modal } from 'reactstrap';

const BookCard = ({
  thumbnail,
  title, //output the title, needed to be sorted
  pageCount,
  language,
  description,
  authors,
  publisher,
  previewLink,
  infoLink,
  connect,
  number
}) => {
  // States
  global.config.i18n.welcome.en3[number] = thumbnail;
  const [modal, setModal] = useState(false);
  const toggle = () => setModal(!modal);
  //const test = title[1];
  const test2 = title.split(' ');
  const test3 = test2[0];
  let test4 = []; // storing first word
  test4 = test4 + test3;
  connect = connect + test4;
  //const new1 = [];
  global.config.i18n.welcome.en[number] = test4;
  const compare = (direction : any) => {
    if (direction === 'asc') {
	return (a : any, b : any) => a > b ? 1 : -1;
    } else if (direction === 'desc') {
	return (a : any, b : any) => b > a ? 1 : -1;
    }
}

console.log('connect', global.config.i18n.welcome.en);


if(number === 9) {

  if(global.config.i18n.welcome.string1 === '1') {
  let segm3SortedWithIndexes = global.config.i18n.welcome.en


  //sort ascending
  .map((f, i) => ({
    floatNumber: f,
    index: i, // <-- original index

  }))
  .sort((a : any, b : any) => a.floatNumber > b.floatNumber ? 1 : -1)
 
    
  for (let k = 0; k < 10; k++) {
    global.config.i18n.welcome.en2[k] = segm3SortedWithIndexes[k].index;
    console.log("sorting list", global.config.i18n.welcome.en2[k])
  }


console.log('"segm3" with original index:', segm3SortedWithIndexes)
const result = segm3SortedWithIndexes.map(({ floatNumber: f }) => f)
console.log('"segm3" sorted:', result)
console.log('Asc order: ', global.config.i18n.welcome.en.sort(compare('asc')));
} else if(global.config.i18n.welcome.string1 === '2') {

  let segm3SortedWithIndexes = global.config.i18n.welcome.en

  //sort descending
  .map((f, i) => ({
    floatNumber: f,
    index: i, // <-- original index
   
  }))
  .sort((a : any, b : any) => b.floatNumber > a.floatNumber ? 1 : -1)
 
    
  for (let k = 0; k < 10; k++) {
    global.config.i18n.welcome.en2[k] = segm3SortedWithIndexes[k].index;
    console.log("sorting list", global.config.i18n.welcome.en2[k])
  }

//display original indexes
console.log('"segm3" with original index:', segm3SortedWithIndexes)
const result = segm3SortedWithIndexes.map(({ floatNumber: f }) => f)
//without index
console.log('"segm3" sorted:', result)
console.log('Asc order: ', global.config.i18n.welcome.en.sort(compare('dsc')));
} else {
  for (let k = 0; k < 10; k++) {
    global.config.i18n.welcome.en2[k] = k;
    console.log(global.config.i18n.welcome.en2[k])
  }
}
  
}

  if(global.config.i18n.welcome.en5 === 1) {
    return (
    <Card style={{ width: '233px' }} className='m-auto '>
    </Card>
    );
    
  } else if(global.config.i18n.welcome.en5 === 2) {
    return (
      <Card style={{ width: '233px' }} className='m-auto '>
      <CardImg
        top
        style={{ width: '100%', height: '233px' }}
        src={thumbnail}
        alt={title}        
      />
  
      <CardBody>
        <CardTitle className='card-title'>{title}</CardTitle>
        
        <Button onClick={toggle}>More info</Button>
      </CardBody>
      <Modal isOpen={modal} toggle={toggle}>
        <div className='modal-header d-flex justify-content-center'>
          <h5 className='modal-title text-center' id='exampleModalLabel'>
            {title}
          </h5>
          <button
            aria-label='Close'
            className='close'
            type='button'
            onClick={toggle}
          >
            <span aria-hidden={true}>X</span>
          </button>
        </div>
        <div className='modal-body'>
          <div className='d-flex justify-content-between ml-3'>
            <img src={thumbnail} alt={title} style={{ height: '233px' }} />
            <div>
              <p>Page Count: {pageCount}</p>
              <p>Language : {language}</p>
              <p>Authors : {authors}</p>
              <p>Publisher : {publisher}</p>
            </div>
          </div>
          <div className='mt-3'>{description}</div>
        </div>
        <div className='modal-footer'>
          <div className='left-silde'>
            <a
              href={previewLink}
              className='btn-link'
              color='default'
              type='button'
              target='_blank'
              rel='noopener noreferrer'
            >
              Preview Link
            </a>
          </div>
          <div className='divider'></div>
          <div className='right-silde'>
            <a
              href={infoLink}
              className='btn-link'
              color='default'
              type='button'
              target='_blank'
              rel='noopener noreferrer'
            >
              Info Link
            </a>
          </div>
        </div>
      </Modal>
    </Card>
    
  );

  }


};

export default BookCard;
