module.exports = global.config = {
    i18n: {
        welcome: {
            en: [], //array
            en2: [], //array2
            en3: [],
            en4: [],
            en5: [],
            en6: [],
            string1: "", //string array
        }
        // rest of your translation object
    }
    // other global config variables you wish
};